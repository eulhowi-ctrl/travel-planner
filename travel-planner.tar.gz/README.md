# 🌍 Travel Planner - AI-Powered Travel Planning Application

여행 계획을 쉽고 편하게 만들어주는 스마트 웹 애플리케이션입니다.

## ✨ 주요 기능

### 🎯 맞춤형 여행지 추천
- **테마별 추천**: 커플, 가족, 혼자, 친구 여행 등 맞춤형 추천
- **가족 구성 고려**: 인원수, 아이 연령대에 따른 최적화된 추천
- **QR 코드**: 여행지 정보 사이트 링크를 QR 코드로 제공

### 📅 자동 일정 생성
- AI 기반 최적의 여행 일정 자동 생성
- 각 여행지별 추천 활동 및 음식점 정보
- 일정 자동 조정 및 커스터마이징

### 🚌 통합 교통편 정보
**장거리 교통**
- 항공사, 기차, 버스 가격 및 시간표 비교
- 실시간 예약 링크 (QR 코드)
- 탑승장소 및 시간 정보

**시내 교통**
- 도착지의 버스, 지하철, 택시 정보
- 운영 시간, 요금, 탑승 방법
- 모바일 앱 다운로드 링크 (QR 코드)

### 💰 예산 계산
- 항공료, 숙박비, 식사비, 활동비 등 항목별 예산
- 통화 환율 자동 환산
- 예산 vs 실제 비용 추적

---

## 🏗️ 프로젝트 구조

```
travel-planner/
├── backend/                          # FastAPI 백엔드
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py                  # FastAPI 애플리케이션
│   │   ├── models.py                # SQLAlchemy 데이터베이스 모델
│   │   ├── schemas.py               # Pydantic 검증 스키마
│   │   ├── database.py              # 데이터베이스 연결 설정
│   │   ├── auth.py                  # JWT 인증 로직
│   │   ├── routers/                 # API 라우터
│   │   │   ├── users.py             # 사용자 관련 API
│   │   │   ├── destinations.py      # 여행지 검색 및 추천
│   │   │   ├── itineraries.py       # 일정 생성 및 관리
│   │   │   ├── transportation.py    # 교통편 정보
│   │   │   └── budgets.py           # 예산 계산
│   │   └── utils/
│   │       └── qr_generator.py      # QR 코드 생성
│   ├── requirements.txt              # Python 패키지 의존성
│   ├── .env.example                 # 환경 변수 예시
│   └── .env                         # 환경 변수 (실제 설정)
│
├── frontend/                         # HTML/CSS/JS 프론트엔드
│   ├── index.html                   # 홈페이지
│   ├── search.html                  # 여행지 검색
│   ├── create-itinerary.html        # 일정 생성
│   ├── transportation.html          # 교통편 정보
│   ├── budget.html                  # 예산 계산
│   ├── style.css                    # 스타일시트
│   └── script.js                    # JavaScript 로직
│
├── static/                          # 정적 파일
│   └── qr_codes/                   # 생성된 QR 코드
│
└── README.md                        # 프로젝트 설명
```

---

## 🛠️ 기술 스택

### Backend
- **Framework**: FastAPI (Python)
- **Database**: PostgreSQL + SQLAlchemy ORM
- **Authentication**: JWT (JSON Web Token)
- **QR Code**: qrcode + Pillow
- **Migration**: Alembic

### Frontend
- **HTML5**, **CSS3**, **Vanilla JavaScript**
- **Responsive Design** (모바일 호환)

### Deployment
- **Server**: Uvicorn
- **Environment**: Python 3.8+

---

## 📦 설치 및 실행

### 1️⃣ 사전 요구사항
- Python 3.8+
- PostgreSQL (또는 SQLite 사용 가능)
- Git

### 2️⃣ 클론 및 셋업

```bash
# 프로젝트 클론
git clone <repository-url>
cd travel-planner

# 가상 환경 생성
python -m venv venv

# 가상 환경 활성화
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate

# 의존성 설치
cd backend
pip install -r requirements.txt
```

### 3️⃣ 환경 변수 설정

```bash
# .env 파일 생성 (예시에서 복사)
cp .env.example .env

# .env 파일 수정 (데이터베이스 URL 등)
# DATABASE_URL=postgresql://user:password@localhost:5432/travel_planner_db
# SECRET_KEY=your-secret-key-here
```

### 4️⃣ 데이터베이스 초기화

```bash
# 데이터베이스 테이블 생성 (자동으로 실행됨)
# 또는 Alembic 마이그레이션 사용:
# alembic upgrade head
```

### 5️⃣ 서버 실행

```bash
# FastAPI 서버 실행
python -m app.main

# 또는 Uvicorn 직접 실행
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 6️⃣ 브라우저에서 확인

```
http://localhost:8000        # API 서버
http://localhost:8000/docs   # Swagger UI 문서
http://localhost:8000/health # 상태 확인
```

---

## 📚 API 엔드포인트 (계획)

### 사용자 관련
```
POST   /api/v1/users/register          # 회원가입
POST   /api/v1/users/login             # 로그인
GET    /api/v1/users/me                # 내 정보 조회
PUT    /api/v1/users/profile           # 프로필 수정
```

### 여행지 관련
```
GET    /api/v1/destinations            # 여행지 목록
GET    /api/v1/destinations/{id}       # 여행지 상세 정보
POST   /api/v1/destinations/search     # 여행지 검색 (테마, 위치 등)
GET    /api/v1/destinations/recommend  # 맞춤형 추천
```

### 교통편 관련
```
GET    /api/v1/transportation/long-distance/search  # 장거리 교통 검색
GET    /api/v1/transportation/local/{destination_id} # 시내 교통 정보
GET    /api/v1/qr-codes/{category}/{id}             # QR 코드 조회
```

### 여행 일정 관련
```
POST   /api/v1/itineraries             # 일정 생성
GET    /api/v1/itineraries             # 내 일정 목록
GET    /api/v1/itineraries/{id}        # 일정 상세 정보
PUT    /api/v1/itineraries/{id}        # 일정 수정
DELETE /api/v1/itineraries/{id}        # 일정 삭제
```

### 예산 관련
```
GET    /api/v1/itineraries/{id}/budgets       # 예산 조회
POST   /api/v1/itineraries/{id}/budgets       # 예산 추가
PUT    /api/v1/budgets/{budget_id}           # 예산 수정
GET    /api/v1/itineraries/{id}/budget-summary # 예산 요약
```

---

## 🗄️ 데이터베이스 스키마

### 주요 테이블
- **users**: 사용자 정보
- **user_profiles**: 사용자 여행 프로필 (테마, 선호도 등)
- **destinations**: 여행지 정보
- **long_distance_transportations**: 장거리 교통 (항공, 기차 등)
- **local_transportations**: 시내 교통 (버스, 지하철, 택시)
- **itineraries**: 여행 일정
- **itinerary_days**: 일정별 일자 정보
- **budgets**: 예산 항목
- **qr_codes**: 생성된 QR 코드

---

## 🚀 개발 로드맵

- [ ] Task #1: 프로젝트 구조 및 FastAPI 환경 설정 ✅
- [ ] Task #2: PostgreSQL 데이터베이스 설계 및 SQLAlchemy 모델 ✅
- [ ] Task #3: 사용자 인증 시스템 구현
- [ ] Task #4: 여행지 검색 및 추천 기능
- [ ] Task #5: 여행 일정 자동 생성
- [ ] Task #6: 예산 계산 및 관리
- [ ] Task #7: 교통편 정보 API
- [ ] Task #8: QR 코드 생성 시스템
- [ ] Task #9: 프론트엔드 UI 구성
- [ ] Task #10: 전체 통합 및 테스트

---

## 🤝 기여 가이드

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📝 라이선스

MIT License

---

## 📧 연락처

Questions? Issues? Feel free to contact us!

---

## 🎉 Happy Traveling! ✈️
