import qrcode
from pathlib import Path
from typing import Optional
import hashlib
import os

# QR 코드 저장 경로
QR_CODE_DIR = Path("static/qr_codes")


def generate_qr_code(
    url: str,
    label: str,
    size: int = 200,
    custom_filename: Optional[str] = None
) -> str:
    """
    URL에서 QR 코드 생성하고 저장

    Args:
        url: QR 코드화할 URL
        label: QR 코드 레이블 (예: "Hotel Booking")
        size: QR 코드 크기 (기본값: 200px)
        custom_filename: 사용자 정의 파일명 (확장자 제외)

    Returns:
        저장된 QR 코드 경로 (예: static/qr_codes/...)

    Example:
        >>> path = generate_qr_code(
        ...     "https://flyasiana.com",
        ...     "Asiana Airlines"
        ... )
        >>> print(path)
        static/qr_codes/asiana_airlines_abc123.png
    """
    # 디렉토리 생성
    QR_CODE_DIR.mkdir(parents=True, exist_ok=True)

    # 파일명 생성 (URL의 해시를 사용해 중복 방지)
    if custom_filename:
        filename = f"{custom_filename}.png"
    else:
        url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
        clean_label = label.lower().replace(" ", "_").replace("/", "_")
        filename = f"{clean_label}_{url_hash}.png"

    file_path = QR_CODE_DIR / filename

    # 이미 존재하면 반환
    if file_path.exists():
        return str(file_path)

    # QR 코드 생성
    qr = qrcode.QRCode(
        version=1,  # 버전 1 (21x21 픽셀 시작)
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,  # 각 박스 크기
        border=2,  # 테두리
    )

    qr.add_data(url)
    qr.make(fit=True)

    # 이미지 생성
    img = qr.make_image(fill_color="black", back_color="white")

    # 크기 조정
    if size != 200:
        from PIL import Image
        img = img.resize((size, size), Image.Resampling.LANCZOS)

    # 저장
    img.save(file_path)

    return str(file_path)


def generate_batch_qr_codes(qr_data_list: list) -> dict:
    """
    여러 개의 QR 코드 일괄 생성

    Args:
        qr_data_list: QR 코드 데이터 리스트
            [
                {
                    "url": "https://example.com",
                    "label": "Example",
                    "filename": "example"  # 선택사항
                },
                ...
            ]

    Returns:
        생성된 QR 코드 경로 딕셔너리
        {
            "label1": "static/qr_codes/...",
            "label2": "static/qr_codes/..."
        }
    """
    results = {}

    for data in qr_data_list:
        url = data.get("url")
        label = data.get("label")
        filename = data.get("filename")

        if url and label:
            path = generate_qr_code(url, label, custom_filename=filename)
            results[label] = path

    return results


def get_qr_code_path(url: str) -> Optional[str]:
    """
    URL에 해당하는 기존 QR 코드 경로 반환

    Args:
        url: 검색할 URL

    Returns:
        QR 코드 경로 또는 None
    """
    url_hash = hashlib.md5(url.encode()).hexdigest()[:8]

    # 디렉토리 내 모든 파일 검색
    for file in QR_CODE_DIR.glob("*_*.png"):
        if url_hash in file.name:
            return str(file)

    return None


def delete_qr_code(filename: str) -> bool:
    """
    QR 코드 파일 삭제

    Args:
        filename: 삭제할 파일명 (경로 포함 가능)

    Returns:
        삭제 성공 여부
    """
    file_path = QR_CODE_DIR / filename if "/" not in filename else filename

    try:
        if Path(file_path).exists():
            Path(file_path).unlink()
            return True
        return False
    except Exception as e:
        print(f"Error deleting QR code: {e}")
        return False


# ==================== 테스트 코드 ====================
if __name__ == "__main__":
    # 단일 QR 코드 생성 테스트
    path = generate_qr_code(
        "https://www.visitjeju.net",
        "Jeju Tourism"
    )
    print(f"✅ QR Code generated: {path}")

    # 일괄 생성 테스트
    qr_list = [
        {
            "url": "https://flyasiana.com",
            "label": "Asiana Airlines"
        },
        {
            "url": "https://www.skyscanner.com",
            "label": "Skyscanner"
        },
        {
            "url": "https://www.agoda.com",
            "label": "Agoda Hotels"
        }
    ]

    results = generate_batch_qr_codes(qr_list)
    print(f"\n✅ Batch QR Codes generated:")
    for label, path in results.items():
        print(f"  - {label}: {path}")
